# DATA_MODEL

Veri modeli özetidir. PostgreSQL hedeflenmiştir.

## Tablolar

### territories
- id (pk, uuid)
- code (text, unique) — Excel `Territory`
- name (text) — ayrıştırılabilirse `TERR030707-Sille` içinden
- created_at, updated_at

### dealers
- id (pk, uuid)
- code (text, unique) — Excel `BayiKodu`
- name (text) — `BayiAdı`
- position_code (text) — `Pozisyon`
- route_order (int) — `BayiRutSırası`
- territory_id (fk -> territories)

### products
- id (pk, uuid)
- code (text, unique) — `ÜrünKodu`
- name (text) — `ÜrünAdı`

### orders
- id (pk, uuid)
- external_order_code (text) — `SiparişKodu`
- payment_type (text) — `ÖdemeTipi`
- order_date (date) — `SiparişTarihi`
- delivery_date (date) — `TeslimatTarihi`
- territory_id (fk)
- dealer_id (fk)
- revision_group_id (uuid) — aynı siparişin versiyonlarını gruplamak için
- revision_no (int) — 1,2,3…
- source_sheet (text) — Recipe2 / Recip1
- imported_at (timestamp)

### order_lines
- id (pk, uuid)
- order_id (fk)
- product_id (fk)
- qty_carton (int) — `Karton`
- qty_pack (int) — `Paket`

### stations
- id (pk, uuid)
- name (text) — İstasyon-1,2,…
- active (bool)
- worker_id (nullable, fk) — depo görevlisi (opsiyonel)

### station_assignments
- id (pk, uuid)
- plan_date (date)
- station_id (fk)
- territory_id (fk)
- load_rank (int) — sayım sırası (1..k)
- target_total_carton (int)
- target_total_pack (int)

### loadsheets
- id (pk, uuid)
- assignment_id (fk -> station_assignments)
- dealer_id (fk)
- sheet_no (text)
- status (enum: pending, loaded, printed, error)
- printed_at, loaded_at

### loadsheet_lines
- id (pk, uuid)
- loadsheet_id (fk)
- product_id (fk)
- qty_carton (int)
- qty_pack (int)

### load_counters
- id (pk, uuid)
- assignment_id (fk)
- count_index (int) — C1..Ck
- remaining_carton (int)
- remaining_pack (int)
- note (text)

## İndeksler
- `orders(external_order_code, revision_no)`
- `dealers(code)`, `products(code)`, `territories(code)`
