# BACKEND_API_SPEC (FastAPI)

## Auth
- JWT Bearer (admin, planner, loader rol’leri)

## ISMS İçe Aktarım
- `POST /v1/import/isms` — body: { run_tag: "14:00"|"16:00", file: Excel }
- `GET /v1/import/isms/diff?group_by=order` — Recipe2 vs Recip1 fark

## Planlama
- `POST /v1/plan/stations` — body: { date, worker_count, method: "greedy"|"ilp" }
- `GET /v1/plan/stations/{date}` — atamalar
- `POST /v1/plan/rebalance` — revizyon sonrası yeniden dengeleme (ops.)

## Fişler
- `GET /v1/loadsheets?date=...&station=...`
- `POST /v1/loadsheets/{id}/print` — PDF render ve durum=printed
- `POST /v1/loadsheets/{id}/loaded` — durum=loaded (kart yeşil)

## Sayım
- `GET /v1/counters/{assignment_id}`
- `POST /v1/counters/{assignment_id}/tick` — {loaded_carton, loaded_pack}

## Canlı
- `GET /v1/events` — SSE/WebSocket (plan değişimi, fiş durumu)
