# Depo Transfer Uygulaması – Dokümantasyon

Bu depo transfer sistemi, PMI ISMS siparişlerinden gelen veriyi (gün içinde 14:00 ve 16:00 çekimleri), depo istasyon planlamasına dönüştürür, istasyon bazlı **yükleme fişleri** üretir ve her yüklemeyi sayım (count) döngülerinde takip eder. Bu klasördeki `.md` belgeler **kaynak sözleşmeler** olup geliştirme sürecinde kanoniktir.

- Kaynak Excel: `e-sipariş.xlsx`
- Veri sayfaları: `Recipe2` (güncel), `Recip1` (revizyon/önceki), `Hazırlık`, `Sipariş Yazdır`
- Toplam sipariş: **53**, bayi: **53**, territory: **14**, satır: **532**
- Territory örnekleri: TERR030701-Bosna-Hersek, TERR030702-Kadınlarpazarı, TERR030703-Sanayi, TERR030704-Mevlana, TERR030705-Meram, TERR030707-Sille, TERR030708-Form, TERR030709-Şeker-Tekke

> Hedef: **Web tabanlı** (React) bir arayüz ve **FastAPI + PostgreSQL** arka uç ile; istasyon planlama, revizyon farkları, sayım döngüleri ve yazdırılabilir fişlerin üretimi.

İlk kuruluma ve sıralı çalışmaya `WORKLIST.md` üzerinden başlayın.
