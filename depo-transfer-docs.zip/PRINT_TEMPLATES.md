# PRINT_TEMPLATES

## Standart Fiş
- Başlık: Tarih, İstasyon, Territory, Bayi Ad/Kod, Adres
- Ürün Tablosu: Ürün Kodu, Adı, Karton, Paket
- Toplamlar
- QR/BarCode (opsiyon: fiş no)

## Revizyonlu Fiş
- Üst blok: ilk versiyon (v1)
- Alt blok: değişiklikler (v2 farkları; sadece artan kalemler)
