# WORKLIST

Bu listedeki fazları **sırayla** uygulayın. Her faz tamamlandığında `DONE` etiketi ekleyin. Kod ajanları için bu belge tek otoritedir.

## FAZ 0 – Proje İskeleleri
- [ ] Repo iskeleti (backend `fastapi`, frontend `react-vite`, `docker-compose`)
- [ ] Ortak `/.env.example` şablonu
- [ ] `make` komutları (dev, test, lint, format, up/down)

## FAZ 1 – Veri Modeli & Migrasyonlar
- [ ] `DATA_MODEL.md` şemasına göre PostgreSQL tabloları
- [ ] Alembic migrasyonları
- [ ] Örnek veriler için `seed` scripti

## FAZ 2 – ISMS İçe Aktarım Hat(ları)
- [ ] `PIPELINES.md` gereği Excel içe aktarımı (Recipe2, Recip1)
- [ ] Revizyon tespiti (diff) ve versiyonlama
- [ ] `EXCEL_MAPPING.md` doğrulama testleri

## FAZ 3 – Planlama & İstasyon Paylaştırma
- [ ] `UI_SPEC.md` ve `ALGO_STATIONS.md` göre istasyon sayısı = aktif depo görevlisi
- [ ] Territory yük dengesi (ürün toplamları yakın) — heuristik/ILP
- [ ] Sayım döngüsü (C1..Ck) hesaplayıcı

## FAZ 4 – API’ler
- [ ] `BACKEND_API_SPEC.md` uç noktaları
- [ ] WebSocket/SSE ile canlı durum

## FAZ 5 – Fiş Üretimi ve Yazdırma
- [ ] `PRINT_TEMPLATES.md` (karton/paket kolonları)
- [ ] Revizyonlu fiş (İlk + Değişiklik ekleri)
- [ ] Çoklu fiş grid görünümü, tıklayınca büyütme, yüklenen = yeşil

## FAZ 6 – Testler
- [ ] `TEST_PLAN.md` Smoke + Fonksiyonel
- [ ] Örnek veriyle uçtan uca test
- [ ] Performans (100k satıra kadar)

## FAZ 7 – Dağıtım
- [ ] `DEPLOYMENT.md` (Docker, Compose, prod notları)
- [ ] Versiyonlama & Sürüm notları
