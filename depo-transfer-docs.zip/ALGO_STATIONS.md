# İstasyon Paylaştırma Algoritması

Amaç: Açılacak istasyon sayısı = depo görevlisi sayısı. Territory’ler, istasyonlara **ürün toplamları birbirine yakın** olacak biçimde dağıtılsın.

## 1) Metriği Seç
- Toplam karton (tercih) ve yardımcı metrik olarak toplam paket.
- Territory skor = Σ ürün satırlarının `Karton` toplamı.

## 2) Heuristik (Hızlı Çözüm)
- Territory’leri skorlarına göre azalan sırala.
- Boş istasyon kovaları oluştur (k adet).
- Her territory’yi, anlık toplamı en düşük olan istasyona ata (greedy load balancing).

## 3) Alternatif: Tamsayılı Programlama (ILP)
- Karar değişkeni: x[t,s] ∈ {0,1} (territory t istasyon s’ye atanır)
- Kısıt: her territory tam 1 istasyona
- Amaç: max yük ile min yük farkını minimize et (veya kareler toplamını)

## 4) Sayım (Counting) Döngüleri
- Her istasyon için C1..Ck sütunları: C(i) = C(i-1) − Yüklenen(i-1)
- Yükleme fişi kapandığında ilgili `remaining_*` güncellenir.
- Bir sonraki fiş hesaplaması önceki `remaining` üzerinden yapılır.

## 5) Revizyon Etkisi
- Aynı `external_order_code` için Recipe2 ve Recip1 farkı alınır.
- Pozitif farklar “ek liste” olarak ilgili territory/istasyon fişine append edilir.
