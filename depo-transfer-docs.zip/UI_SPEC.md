# UI_SPEC (React)

## Sayfalar
1. **Planlama Paneli**
   - Çalışan sayısı gir, “Planı Oluştur”
   - İstasyon kartları: toplam karton/paket, territory listesi
   - Revizyon farkları uyarısı

2. **Fiş Grid**
   - Tüm fişler küçük kart olarak (PDF/sanal önizleme)
   - Tıklayınca büyür (modal)
   - Durum renkleri: pending (gri), printed (mavi), loaded (yeşil), error (kırmızı)
   - Filtre: istasyon, territory, durum

3. **Sayım Ekranı**
   - C1..Ck sütunları
   - “Yükleme Tamamlandı” -> kalan otomatik güncellenir
   - Canlı bildirim

## Bileşenler
- `StationCard`, `LoadsheetTile`, `LoadsheetModal`, `CounterTable`, `DiffBadge`, `TerritoryChip`

## Yazdırma
- Her fiş kendi sayfasında (A5/A6 öneri)
- “Kart/PKT” kolonları
- Revizyon varsa “Ek Liste” bloğu
